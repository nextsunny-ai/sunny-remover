#!/bin/bash
# 이 창에서 하는 일: 맥에서 영상다운로더 실행
export PATH="/opt/homebrew/bin:/usr/local/bin:$PATH"
"$HOME/SUNNY_WORK/venv_영상다운로더/bin/python" "$(dirname "$0")/영상다운로더.pyw" &
