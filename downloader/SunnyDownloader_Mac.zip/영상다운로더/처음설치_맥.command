#!/bin/bash
# 이 창에서 하는 일: 맥에 영상다운로더 설치 (홈브루 python 3.12·tk·ffmpeg + 전용 가상환경 yt-dlp + 바탕화면 앱)
set -e
HERE="$(cd "$(dirname "$0")" && pwd)"
APP_NAME="Sunny Downloader"
OLD_APP="$HOME/Desktop/써니팀 영상 다운로더.app"  # 예전 이름 앱은 지운다
VENV="$HOME/SUNNY_WORK/venv_영상다운로더"
export PATH="/opt/homebrew/bin:/usr/local/bin:$PATH"

echo "▶ 0/4 맥 보안 차단 해제(이 폴더만)"
xattr -dr com.apple.quarantine "$HERE" 2>/dev/null || true
chmod +x "$HERE/실행_맥.command" "$HERE/처음설치_맥.command" 2>/dev/null || true

if ! command -v brew >/dev/null 2>&1; then
  echo "▶ 홈브루가 없어 설치합니다. 맥 로그인 비밀번호를 한 번 물어봅니다."
  /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
  export PATH="/opt/homebrew/bin:/usr/local/bin:$PATH"
fi

echo "▶ 1/4 python 3.12 / tk / ffmpeg 설치 (처음이면 몇 분 걸립니다)"
brew install python@3.12 python-tk@3.12 ffmpeg

echo "▶ 2/4 전용 가상환경 + yt-dlp"
"$(brew --prefix python@3.12)/bin/python3.12" -m venv "$VENV"
"$VENV/bin/pip" install -q -U yt-dlp
"$VENV/bin/pip" install -q pywebview || echo "  (로그인 창 부품은 처음 쓸 때 자동 설치됩니다)"

echo "▶ 3/4 바탕화면 앱 만들기"
W="$(mktemp -d)"
mkdir "$W/i.iconset"
for s in 16 32 64 128 256 512; do
  sips -z $s $s "$HERE/아이콘.png" --out "$W/i.iconset/icon_${s}x${s}.png" >/dev/null
  d=$((s * 2))
  sips -z $d $d "$HERE/아이콘.png" --out "$W/i.iconset/icon_${s}x${s}@2x.png" >/dev/null
done
iconutil -c icns "$W/i.iconset" -o "$W/app.icns"
APP="$HOME/Desktop/$APP_NAME.app"
rm -rf "$APP" "$OLD_APP"
osacompile -o "$APP" -e "do shell script \"\\\"$VENV/bin/python\\\" \\\"$HERE/영상다운로더.pyw\\\" > /dev/null 2>&1 &\""
cp "$W/app.icns" "$APP/Contents/Resources/applet.icns"
rm -f "$APP/Contents/Resources/Assets.car"
/usr/libexec/PlistBuddy -c "Delete :CFBundleIconName" "$APP/Contents/Info.plist" 2>/dev/null || true
codesign --force --deep -s - "$APP" >/dev/null 2>&1 || true
touch "$APP"
rm -rf "$W"

echo "▶ 4/4 확인"
"$VENV/bin/python" -c "import yt_dlp, tkinter; print('  yt-dlp', yt_dlp.version.__version__, '/ tk', tkinter.TkVersion)"
echo ""
echo "설치 끝. 바탕화면의 '$APP_NAME'을 더블클릭하세요."
echo "※ 이 폴더를 옮기거나 지우면 앱이 안 열립니다. 옮겼다면 이 설치를 한 번 더 실행하세요."
