# -*- coding: utf-8 -*-
"""이 창에서 하는 일: 윈도우 PC에 영상다운로더 실행 준비(yt-dlp 설치·ffmpeg 확인·바탕화면 바로가기)."""
import os
import shutil
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
APP = os.path.join(HERE, "영상다운로더.pyw")
LINK_NAME = "Sunny Downloader.lnk"
OLD_LINK_NAMES = ["써니팀 영상 다운로더.lnk"]  # 예전 이름 아이콘은 지운다
ICON = os.path.join(HERE, "아이콘.ico")


def step(msg):
    print(f"\n▶ {msg}", flush=True)


def install_ytdlp():
    step("yt-dlp 설치/업데이트")
    r = subprocess.run([sys.executable, "-m", "pip", "install", "-U", "yt-dlp"])
    if r.returncode != 0:
        sys.exit("yt-dlp 설치 실패 — 인터넷 연결을 확인하세요.")


def check_ffmpeg():
    step("ffmpeg 확인")
    if shutil.which("ffmpeg"):
        print("  ffmpeg 있음")
        return
    print("  ffmpeg 없음 → winget으로 설치 시도")
    r = subprocess.run(["winget", "install", "-e", "--id", "Gyan.FFmpeg", "--accept-source-agreements", "--accept-package-agreements"])
    if r.returncode != 0:
        print("  ffmpeg 자동 설치 실패 — 1080p 합치기에 필요합니다. 명령창에서 winget install Gyan.FFmpeg 를 실행하세요.")


def make_shortcut():
    step("바탕화면 바로가기 만들기")
    pyw = os.path.join(os.path.dirname(sys.executable), "pythonw.exe")
    if not os.path.exists(pyw):
        pyw = shutil.which("pythonw") or sys.executable
    ps = (
        "$d=[Environment]::GetFolderPath('Desktop');"
        f"$s=(New-Object -ComObject WScript.Shell).CreateShortcut((Join-Path $d '{LINK_NAME}'));"
        f"$s.TargetPath='{pyw}';$s.Arguments='\"{APP}\"';$s.WorkingDirectory='{HERE}';"
        f"$s.IconLocation='{ICON},0';$s.Save();"
        + "".join(f"Remove-Item -LiteralPath (Join-Path $d '{old}') -ErrorAction SilentlyContinue;"
                  for old in OLD_LINK_NAMES)
        + "exit 0"  # 예전 아이콘이 없어서 지우기가 실패해도 설치는 성공
    )
    r = subprocess.run(["powershell", "-NoProfile", "-Command", ps])
    print("  완료" if r.returncode == 0 else "  바로가기 실패 — 영상다운로더_실행.bat을 쓰세요.")


if __name__ == "__main__":
    install_ytdlp()
    check_ffmpeg()
    make_shortcut()
    print("\n설치 끝. 바탕화면의 'Sunny Downloader'를 더블클릭하세요.")
