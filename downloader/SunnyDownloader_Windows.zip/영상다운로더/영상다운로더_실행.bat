@echo off
chcp 65001 >nul
start "" pythonw "%~dp0영상다운로더.pyw"
