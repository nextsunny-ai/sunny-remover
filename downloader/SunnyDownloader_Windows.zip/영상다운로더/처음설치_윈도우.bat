@echo off
chcp 65001 >nul
python -c "import sys" >nul 2>nul
if errorlevel 1 (
  echo [1/2] Python not found. Installing Python 3.12 ...
  winget install -e --id Python.Python.3.12 --scope user --accept-source-agreements --accept-package-agreements
  set "PATH=%LOCALAPPDATA%\Programs\Python\Python312;%LOCALAPPDATA%\Programs\Python\Python312\Scripts;%PATH%"
)
echo [2/2] Setting up downloader ...
python "%~dp0setup_windows.py"
pause
